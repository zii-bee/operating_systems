#ifndef PIPES_H
#define PIPES_H

void execute_pipeline(const char *input);

#endif // PIPES_H
