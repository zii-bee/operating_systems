#ifndef CLIENT_H
#define CLIENT_H

void start_client(const char *ip, int port);

#endif