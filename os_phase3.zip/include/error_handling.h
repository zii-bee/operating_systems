#ifndef ERROR_HANDLING_H
#define ERROR_HANDLING_H

void handle_error(const char *msg);

#endif // ERROR_HANDLING_H
